<?php
// src/Arcanine.php
require_once __DIR__ . '/Pokemon.php';

class Arcanine extends Pokemon
{
    public function __construct(int $level, int $hp, int $maxHp, int $exp)
    {
        parent::__construct('Arcanine', 'Fire', $level, $hp, $maxHp, $exp);
    }

    protected function getSpecialMoveDescription(): string
    {
        return "Flare Blitz - Serangan api super kuat yang bisa membakar lawan dan menguras stamina.";
    }

    protected function calculateTrainingEffect(string $trainingType, int $intensity): array
    {
        $intensity = max(1, min(10, $intensity)); // clamp 1-10
        $expGain   = 0;
        $hpGain    = 0;
        $detail    = '';

        switch ($trainingType) {
            case 'strength':
                // Arcanine (Fire) unggul di Strength
                $expGain = 15 * $intensity;
                $hpGain  = 2 * $intensity;
                $detail  = "Latihan Strength meningkatkan kekuatan serangan api Arcanine.";
                break;

            case 'speed':
                $expGain = 12 * $intensity;
                $hpGain  = 1 * $intensity;
                $detail  = "Latihan Speed membuat Arcanine berlari secepat kilat.";
                break;

            case 'defense':
            default:
                $expGain = 8 * $intensity;
                $hpGain  = 3 * $intensity;
                $detail  = "Latihan Defense melatih ketahanan tubuh Arcanine terhadap serangan.";
                break;
        }

        return [
            'expGain' => $expGain,
            'hpGain'  => $hpGain,
            'detail'  => $detail
        ];
    }
}