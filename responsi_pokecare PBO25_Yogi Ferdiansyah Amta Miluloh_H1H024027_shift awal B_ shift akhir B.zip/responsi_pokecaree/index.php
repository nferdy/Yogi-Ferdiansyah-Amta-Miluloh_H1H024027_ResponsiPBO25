<?php
require_once __DIR__ . '/src/GameManager.php';

$game = new GameManager();
$pokemon = $game->getPokemon();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>PokéCare - Arcanine</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body class="bg">

    <body class="bg">
    <div class="fire-background">
        <div class="fire-glow-base"></div>
        <div class="fire-wave wave1"></div>
        <div class="fire-wave wave2"></div>
        <div class="fire-wave wave3"></div>
    </div>

    <div class="hero-wrapper">
        <div class="hero-panel hero-left">
            <h1 class="logo-text">POKÉCARE</h1>

            <div class="stat-group">
                <div class="stat-row">
                    <span>Level</span>
                    <strong><?= $pokemon->getLevel(); ?></strong>
                </div>
                <div class="stat-row">
                    <span>HP</span>
                    <strong><?= $pokemon->getHp(); ?>/<?= $pokemon->getMaxHp(); ?></strong>
                </div>
                <div class="stat-row">
                    <span>Type</span>
                    <strong><?= $pokemon->getType(); ?></strong>
                </div>
                <div class="stat-row">
                    <span>EXP</span>
                    <strong><?= $pokemon->getExp(); ?>/100</strong>
                </div>
            </div>

            <div class="btn-row">
                <a href="train.php" class="btn primary">Start Training</a>
                <a href="history.php" class="btn ghost">Training History</a>
            </div>
        </div>

        <div class="hero-center">
            <div class="card-back"></div>
            <div class="hero-glow"></div>
            <img src="assets/arcanine.png" class="hero-image">
        </div>

        <div class="hero-panel hero-right">
            <div class="name-row">
                <h2>Arcanine</h2>
                <span class="tag-fire">FIRE</span>
            </div>

            <div class="bar-list">
                <div class="bar-item">
                    <span>Attack</span>
                    <div class="bar"><div class="bar-fill attack"></div></div>
                </div>
                <div class="bar-item">
                    <span>Defense</span>
                    <div class="bar"><div class="bar-fill defense"></div></div>
                </div>
                <div class="bar-item">
                    <span>Speed</span>
                    <div class="bar"><div class="bar-fill speed"></div></div>
                </div>
            </div>

            <div class="special-box">
                <h3>Special Move</h3>
                <p><?= $pokemon->specialMove(); ?></p>
            </div>
        </div>

    </div>


</body>
</html>