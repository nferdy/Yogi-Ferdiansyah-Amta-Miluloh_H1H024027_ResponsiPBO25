<?php
require_once __DIR__ . '/src/GameManager.php';

$game     = new GameManager();
$pokemon  = $game->getPokemon();
$history  = $game->getHistory(); 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Training History - PokéCare</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body class="bg">

    <div class="fire-background">
        <div class="fire-glow-base"></div>
        <div class="fire-wave wave1"></div>
        <div class="fire-wave wave2"></div>
        <div class="fire-wave wave3"></div>
    </div>

    <div class="hero-wrapper history-layout">

        <div class="hero-panel">
            <h1 class="logo-text">HISTORY</h1>

            <div class="stat-group">
                <div class="stat-row">
                    <span>Pokemon</span>
                    <strong><?= $pokemon->getName(); ?></strong>
                </div>
                <div class="stat-row">
                    <span>Level</span>
                    <strong><?= $pokemon->getLevel(); ?></strong>
                </div>
                <div class="stat-row">
                    <span>HP</span>
                    <strong><?= $pokemon->getHp(); ?>/<?= $pokemon->getMaxHp(); ?></strong>
                </div>
                <div class="stat-row">
                    <span>Type</span>
                    <strong><?= $pokemon->getType(); ?></strong>
                </div>
            </div>

            <div class="btn-row">
                <a href="index.php" class="btn primary">Back Home</a>
                <a href="train.php" class="btn ghost">Train Again</a>
            </div>
        </div>

        <div class="hero-panel history-panel">
            <div class="name-row">
                <h2>Training History</h2>
            </div>

            <?php if (!empty($history)): ?>
                <div class="history-table-wrapper">
                    <table class="history-table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Time</th>
                                <th>Type</th>
                                <th>Intensity</th>
                                <th>Level</th>
                                <th>HP</th>
                                <th>Detail</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach (array_reverse($history) as $index => $entry): ?>
                            <tr>
                                <td><?= $index + 1; ?></td>
                                <td><?= htmlspecialchars($entry['time'] ?? '-'); ?></td>
                                <td><?= ucfirst(htmlspecialchars($entry['type'] ?? '-')); ?></td>
                                <td><?= htmlspecialchars($entry['intensity'] ?? '-'); ?></td>
                                <td>
                                    <?= $entry['level_before'] ?? '?'; ?>
                                    →
                                    <strong><?= $entry['level_after'] ?? '?'; ?></strong>
                                </td>
                                <td>
                                    <?= $entry['hp_before'] ?? '?'; ?>
                                    →
                                    <strong><?= $entry['hp_after'] ?? '?'; ?></strong>
                                </td>
                                <td class="history-detail">
                                    <?= htmlspecialchars($entry['detail'] ?? ''); ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p class="history-empty">Belum ada sesi latihan.</p>
            <?php endif; ?>
        </div>

    </div>
</body>
</html>