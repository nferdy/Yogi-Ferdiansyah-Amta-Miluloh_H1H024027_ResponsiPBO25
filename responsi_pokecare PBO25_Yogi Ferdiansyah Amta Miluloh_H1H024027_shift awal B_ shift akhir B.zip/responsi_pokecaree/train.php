<?php
require_once __DIR__ . '/src/GameManager.php';

$game = new GameManager();
$pokemon = $game->getPokemon();
$result = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $trainingType = $_POST['training_type'] ?? 'strength';
    $intensity    = (int)($_POST['intensity'] ?? 1);

    $trainResult  = $pokemon->train($trainingType, $intensity);

    $game->savePokemon($pokemon);
    $game->addHistory([
        'type'        => $trainingType,
        'intensity'   => $intensity,
        'level_before'=> $trainResult['before']['level'],
        'level_after' => $trainResult['after']['level'],
        'hp_before'   => $trainResult['before']['hp'],
        'hp_after'    => $trainResult['after']['hp'],
        'time'        => date('Y-m-d H:i:s'),
        'detail'      => $trainResult['detail']
    ]);

    $result = $trainResult;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Training Session - PokéCare</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body class="bg">
    <div class="fire-background">
        <div class="fire-glow-base"></div>
        <div class="fire-wave wave1"></div>
        <div class="fire-wave wave2"></div>
        <div class="fire-wave wave3"></div>
    </div>

    <div class="hero-wrapper train-layout">
        <div class="hero-panel">
            <h1 class="logo-text">TRAINING SESSION</h1>

            <form method="post" class="train-form">

                <label class="train-label">Training Type</label>
                <div class="toggle-row">
                    <label class="toggle-pill">
                        <input type="radio" name="training_type" value="strength" checked>
                        <span>Strength</span>
                    </label>
                    <label class="toggle-pill">
                        <input type="radio" name="training_type" value="speed">
                        <span>Speed</span>
                    </label>
                    <label class="toggle-pill">
                        <input type="radio" name="training_type" value="defense">
                        <span>Defense</span>
                    </label>
                </div>

                <label class="train-label">Intensity (1–10)</label>
                <div class="intensity-row">
                    <?php for ($i = 1; $i <= 10; $i++): ?>
                        <button type="submit" name="intensity" value="<?= $i ?>" class="intensity-btn">
                            <?= $i ?>
                        </button>
                    <?php endfor; ?>
                </div>

                <div class="btn-row train-actions">
                    <a href="index.php" class="btn ghost">Back Home</a>
                    <a href="history.php" class="btn ghost">History</a>
                </div>
            </form>
        </div>

        <div class="hero-center">
            <div class="card-back"></div>
            <div class="hero-glow"></div>
            <img src="assets/arcanine.png" alt="Arcanine" class="hero-image">
        </div>

        <div class="hero-panel hero-right">
            <div class="name-row">
                <h2>Arcanine Lv. <?= $pokemon->getLevel(); ?></h2>
                <span class="tag-fire">FIRE</span>
            </div>

            <p class="train-status">
                HP: <?= $pokemon->getHp(); ?>/<?= $pokemon->getMaxHp(); ?><br>
                EXP: <?= $pokemon->getExp(); ?>/100
            </p>

            <?php if ($result): ?>
                <div class="result-box">
                    <h3>Training Result</h3>
                    <p><?= htmlspecialchars($result['detail']); ?></p>
                    <p class="result-stats">
                        Level: <?= $result['before']['level']; ?> → <strong><?= $result['after']['level']; ?></strong><br>
                        HP: <?= $result['before']['hp']; ?> → <strong><?= $result['after']['hp']; ?></strong>
                    </p>
                </div>
            <?php else: ?>
                <div class="result-box muted">
                    <p>Lakukan training untuk melihat hasil di sini.</p>
                </div>
            <?php endif; ?>

        </div>

    </div>
</body>
</html>