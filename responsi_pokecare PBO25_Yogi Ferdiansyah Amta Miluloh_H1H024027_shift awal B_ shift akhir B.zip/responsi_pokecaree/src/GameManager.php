<?php
require_once __DIR__ . '/Arcanine.php';

class GameManager
{
    private string $pokemonFile;
    private string $historyFile;

    public function __construct()
    {
        $this->pokemonFile = __DIR__ . '/../data/pokemon.json';
        $this->historyFile = __DIR__ . '/../data/history.json';
    }

    public function getPokemon(): Pokemon
    {
        if (!file_exists($this->pokemonFile)) {
            throw new Exception('pokemon.json tidak ditemukan');
        }

        $data = json_decode(file_get_contents($this->pokemonFile), true);

        return new Arcanine(
            $data['level'],
            $data['hp'],
            $data['maxHp'],
            $data['exp']
        );
    }

    public function savePokemon(Pokemon $pokemon): void
    {
        $data = [
            'name'   => $pokemon->getName(),
            'type'   => $pokemon->getType(),
            'level'  => $pokemon->getLevel(),
            'hp'     => $pokemon->getHp(),
            'maxHp'  => $pokemon->getMaxHp(),
            'exp'    => $pokemon->getExp()
        ];

        file_put_contents(
            $this->pokemonFile,
            json_encode($data, JSON_PRETTY_PRINT)
        );
    }

    public function addHistory(array $entry): void
    {
        if (!file_exists($this->historyFile)) {
            file_put_contents($this->historyFile, json_encode([]));
        }

        $history   = json_decode(file_get_contents($this->historyFile), true);
        $history[] = $entry;

        file_put_contents(
            $this->historyFile,
            json_encode($history, JSON_PRETTY_PRINT)
        );
    }

    public function getHistory(): array
    {
        if (!file_exists($this->historyFile)) {
            return [];
        }
        return json_decode(file_get_contents($this->historyFile), true);
    }
}
