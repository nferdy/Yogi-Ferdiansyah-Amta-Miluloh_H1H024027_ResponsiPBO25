<?php
// src/Pokemon.php
abstract class Pokemon
{
    protected string $name;
    protected string $type;
    protected int $level;
    protected int $hp;
    protected int $maxHp;
    protected int $exp;

    public function __construct(
        string $name,
        string $type,
        int $level,
        int $hp,
        int $maxHp,
        int $exp = 0
    ) {
        $this->name   = $name;
        $this->type   = $type;
        $this->level  = $level;
        $this->hp     = $hp;
        $this->maxHp  = $maxHp;
        $this->exp    = $exp;
    }

    // ==== Encapsulation: getter sederhana ====
    public function getName(): string { return $this->name; }
    public function getType(): string { return $this->type; }
    public function getLevel(): int { return $this->level; }
    public function getHp(): int { return $this->hp; }
    public function getMaxHp(): int { return $this->maxHp; }
    public function getExp(): int { return $this->exp; }

    // ==== Method umum untuk semua pokemon ====
    public function specialMove(): string
    {
        return $this->getSpecialMoveDescription();
    }

    // Abstraction & Polymorphism → di-override di child
    abstract protected function getSpecialMoveDescription(): string;

    // Abstraction & Polymorphism → perhitungan stat beda per tipe
    abstract protected function calculateTrainingEffect(
        string $trainingType,
        int $intensity
    ): array;

    /**
     * train() dipanggil dari halaman latihan
     * return: data before/after buat ditampilkan & disimpan history
     */
    public function train(string $trainingType, int $intensity): array
    {
        $before = [
            'level' => $this->level,
            'hp'    => $this->hp
        ];

        $effect = $this->calculateTrainingEffect($trainingType, $intensity);

        $this->exp  += $effect['expGain'];
        $this->hp   = min($this->maxHp, $this->hp + $effect['hpGain']);

        // Level up tiap 100 exp (contoh)
        while ($this->exp >= 100) {
            $this->exp -= 100;
            $this->level++;
            $this->maxHp += 5;
            $this->hp = $this->maxHp;
        }

        $after = [
            'level' => $this->level,
            'hp'    => $this->hp
        ];

        return [
            'before' => $before,
            'after'  => $after,
            'detail' => $effect['detail']
        ];
    }
}
